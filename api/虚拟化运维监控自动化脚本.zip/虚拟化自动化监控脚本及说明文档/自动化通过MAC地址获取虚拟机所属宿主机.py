#!/usr/bin/env python 
#-*- coding:utf-8 -*-
#author:xiatian

import ssl
ssl._create_default_https_context = ssl._create_unverified_context
import atexit 
 
from pyVim import connect 
from pyVmomi import vmodl 
from pyVmomi import vim 
'''
with open("/tmp/mac.txt","r+") as f1:
	for line in f1:
        	print line.strip()
'''
f = open("/tmp/mac.txt", 'r')
a=f.read().strip()
f.close()


def print_vm_info(virtual_machine): 
    for device in virtual_machine.config.hardware.device: 
        if (device.key >= 4000) and (device.key < 5000): 
            if device.macAddress == a: 
                print('device.macAddress==', device.macAddress) 
 
                summary = virtual_machine.summary 
                print("Name       : ", summary.config.name) 
                print("Template   : ", summary.config.template) 
                print("Path       : ", summary.config.vmPathName) 
                print("Guest      : ", summary.config.guestFullName) 
                print("Host       : ", summary.runtime.host.name) 
 
def main(): 
    try: 
        service_instance = connect.SmartConnect(host="192.168.0.24", 
                                                user="administrator@vsphere.local", 
                                                pwd="Toprs!@#123", 
                                                port=443) 
 
        atexit.register(connect.Disconnect, service_instance) 
 
        content = service_instance.RetrieveContent() 
 
        container = content.rootFolder  # starting point to look into 
        viewType = [vim.VirtualMachine]  # object types to look for 
        recursive = True  # whether we should look into it recursively 
        containerView = content.viewManager.CreateContainerView( 
            container, viewType, recursive) 
 
        children = containerView.view 
        for child in children: 
            print_vm_info(child) 
 
    except vmodl.MethodFault as error: 
        print("Caught vmodl fault : " + error.msg) 
        return -1 
 
    return 0 
 
# Start program 
if __name__ == "__main__": 
    main() 
