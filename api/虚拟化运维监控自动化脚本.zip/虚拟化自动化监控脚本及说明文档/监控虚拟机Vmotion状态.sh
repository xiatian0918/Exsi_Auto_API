#!/bin/sh
#author:xiatian


#date_5min_ago=`date -d '5 minute ago' +%H-%M`
date_now=`date -d 'now' +%H-%M`
#date_10min_ago=`date -d '10 minute ago' +%H-%M`

read -t 18 -p "请输入要查看虚拟机Vmotion状态的IP地址: " vm_name
if [ -z $vm_name ];then
        echo ""
        exit 2
fi

[ ! -d /tmp/vmotion ] && mkdir -p /tmp/vmotion

/bin/python /data/scripts/自动化通过MAC地址获取虚拟机所属宿主机.py |grep Host|cut -d':' -f2|awk -F\, '{print $2}'|awk -F\) '{print $1}'|awk -F\' '{print $2}'|cut -d'.' -f4 >/tmp/vmotion/$date_now
exsi2=$(cat /tmp/vmotion/$date_now)
echo "虚拟机“$vm_name,现在所属EXSI主机为: $exsi2"

sleep 5m

/bin/python /data/scripts/自动化通过MAC地址获取虚拟机所属宿主机.py |grep Host|cut -d':' -f2|awk -F\, '{print $2}'|awk -F\) '{print $1}'|awk -F\' '{print $2}'|cut -d'.' -f4>/tmp/vmotion/$date_now
exsi1=$(cat /tmp/vmotion/$date_now)

echo "虚拟机“$vm_name,5分钟后所属EXSI主机为: $exsi2"


if [ "$exsi1" == "$exsi2" ];then
	echo "虚拟机“$vm_name” 没有发生vmotion,所属EXSI主机为: $exsi2"
else
	echo "虚拟机“$vm_name” 已发生vmotion,所属EXSI主机为: $exsi1"
fi

rm -rf /tmp/vmotion/*.txt
