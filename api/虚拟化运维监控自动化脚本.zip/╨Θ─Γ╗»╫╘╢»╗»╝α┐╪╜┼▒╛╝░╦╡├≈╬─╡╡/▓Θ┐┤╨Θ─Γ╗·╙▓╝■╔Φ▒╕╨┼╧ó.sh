#!/bin/sh

read -t 18 -p "请输入查看的虚拟机IP地址为: " vm_ip
if [ -z $vm_ip ];then
        echo ""
        exit 2
fi

/usr/bin/python /data/scripts/虚拟机硬件设备信息.py -s'192.168.0.24' -u'administrator@vsphere.local' -p'Toprs!@#123' -i "$vm_ip"
